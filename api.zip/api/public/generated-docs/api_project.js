define({
  "name": "TrackMe API",
  "version": "1.0.0",
  "description": "List of endpoints for the TrackMe API",
  "title": "TrackMe API",
  "url": "http://localhost:5000",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-08-01T12:55:33.551Z",
    "url": "http://apidocjs.com",
    "version": "0.24.0"
  }
});
