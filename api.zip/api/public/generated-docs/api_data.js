define({ "api": [
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "./public/generated-docs/main.js",
    "group": "C:\\Users\\vansh\\codingfile\\code\\SIT209\\TrackMe\\api\\public\\generated-docs\\main.js",
    "groupTitle": "C:\\Users\\vansh\\codingfile\\code\\SIT209\\TrackMe\\api\\public\\generated-docs\\main.js",
    "name": ""
  },
  {
    "type": "get",
    "url": "/api/devices",
    "title": "AllDevices An array of all devices",
    "group": "Device",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "[\n{\n\"_id\": \"dsohsdohsdofhsofhosfhsofh\",\n\"name\": \"Mary's iPhone\",\n\"user\": \"mary\",\n\"sensorData\": [\n{\n\"ts\": \"1529542230\",\n\"temp\": 12,\n\"loc\": {\n\"lat\": -37.84674,\n\"lon\": 145.115113\n}\n},\n{\n\"ts\": \"1529572230\",\n\"temp\": 17,\n\"loc\": {\n\"lat\": -37.850026,\n\"lon\": 145.117683\n}\n}\n]\n}\n]",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "{\n\"User does not exist\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./api.js",
    "groupTitle": "Device",
    "name": "GetApiDevices"
  },
  {
    "type": "get",
    "url": "/api/users/:user/devices",
    "title": "AllDevices An array of users",
    "group": "Device_with_the_user_names",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "[\n{\n\"sensorData\": [],\n\"_id\": \"5f225c5b866960ead8027cd0\",\n\"name\": \"apple\",\n\"user\": \"test\",\n\"__v\": 0\n},\n{\n\"sensorData\": [\n{\n\"ts\": \"1529545935\",\n\"temp\": 14,\n\"loc\": {\n\"lat\": -37.839587,\n\"lon\": 145.101386\n}\n}\n]\n},\n{\n\"_id\": \"5f19550f21c699eb8c6ef582\",\n\"name\": \"Bob's Samsung Galaxy\",\n\"user\": \"bob\",\n\"id\": \"7\"\n},\n{\n\"sensorData\": [\n{\n\"ts\": \"1529572230\",\n\"temp\": 14,\n\"loc\": {\n\"lat\": -37.850026,\n\"lon\": 145.117683\n}\n}\n]\n},\n{\n\"sensorData\": [\n{\n\"ts\": \"1529545935\",\n\"temp\": 14,\n\"loc\": {\n\"lat\": -37.839587,\n\"lon\": 145.101386\n}\n}\n],\n\"_id\": \"5f195755d15e4b29145af3f2\",\n\"name\": \"Bob's Samsung Galaxy\",\n\"user\": \"bob\",\n\"id\": \"7\"\n},\n{\n\"_id\": \"5f19550f21c699eb8c6ef583\",\n\"id\": \"2\",\n\"name\": \"Sam's iPhone\",\n\"user\": \"sam\"\n}\n]",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "{\n\"User does not exist\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./api.js",
    "groupTitle": "Device_with_the_user_names",
    "name": "GetApiUsersUserDevices"
  },
  {
    "type": "get",
    "url": "/api/devices/:deviceId/device-history",
    "title": "AllDevices An array of device id",
    "group": "Device_with_their_Id's",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "[\n{\n{\n\"ts\": \"1529542230\",\n\"temp\": 12,\n\"loc\": {\n\"lat\": -37.84674,\n\"lon\": 145.115113\n},\n{\n\"ts\": \"1529572230\",\n\"temp\": 17,\n\"loc\": {\n\"lat\": -37.850026,\n\"lon\": 145.117683\n}\n{\n\"ts\": \"1529545935\",\n\"temp\": 14,\n\"loc\": {\n\"lat\": -37.839587,\n\"lon\": 145.101386\n}\n}\n]",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "{\n\"null\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./api.js",
    "groupTitle": "Device_with_their_Id's",
    "name": "GetApiDevicesDeviceidDeviceHistory"
  },
  {
    "type": "get",
    "url": "/api/test",
    "title": "Test API",
    "group": "Test",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "'The API is working!'",
          "type": "string"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "{\n\"null\"\n}",
          "type": "string"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./api.js",
    "groupTitle": "Test",
    "name": "GetApiTest"
  }
] });
